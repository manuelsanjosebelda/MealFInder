import React from "react";

type Props = {};

const Categories = (props: Props) => {
  return <div>Categories</div>;
};

export default Categories;
